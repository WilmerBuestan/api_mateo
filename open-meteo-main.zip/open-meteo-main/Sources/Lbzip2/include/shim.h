

#ifndef _LBZIP2_
#define _LBZIP2_

#include <stddef.h>

#include "../src/common.h"
#include "../src/decode.h"

//void windirectionFast(const size_t num_points, const float* ys, const float* xs, float* out);


/*void display_mallinfo2(void);

void chelper_malloc_trim(void);*/

#endif // _LBZIP2_
