import Foundation
import Vapor

struct DemController {
    func query(_ req: Request) async throws -> Response {
        try await req.withApiParameter("api") { _, params in
            let latitude = params.latitude
            let longitude = params.longitude

            guard latitude.count == longitude.count else {
                throw ForecastApiError.latitudeAndLongitudeSameCount
            }
            guard !latitude.isEmpty else {
                throw ForecastApiError.latitudeAndLongitudeNotEmpty
            }
            guard latitude.count <= 100 else {
                throw ForecastApiError.latitudeAndLongitudeMaximum(max: 100)
            }
            try zip(latitude, longitude).forEach { latitude, longitude in
                if latitude > 90 || latitude < -90 || latitude.isNaN {
                    throw ForecastApiError.latitudeMustBeInRangeOfMinus90to90(given: latitude)
                }
                if longitude > 180 || longitude < -180 || longitude.isNaN {
                    throw ForecastApiError.longitudeMustBeInRangeOfMinus180to180(given: longitude)
                }
            }
            return DemResponder(latitude: latitude, longitude: longitude, logger: req.logger, httpClient: req.application.http.client.shared)
        }
    }
}

fileprivate struct DemResponder: ForecastapiResponder {
    var numberOfLocations: Int { 1 }

    let latitude: [Float]
    let longitude: [Float]
    let logger: Logger
    let httpClient: HTTPClient

    func calculateQueryWeight(nVariablesModels: Int?) -> Float {
        return Float(nVariablesModels ?? latitude.count)
    }

    func response(format: ForecastResultFormatWithOptions?, concurrencySlot: Int?) async throws -> Response {
        let elevation = try await zip(latitude, longitude).asyncMap { latitude, longitude in
            try await Dem90.read(lat: latitude, lon: longitude, logger: logger, httpClient: httpClient)
        }
        var headers = HTTPHeaders()
        headers.add(name: .contentType, value: "application/json")
        return Response(status: .ok, headers: headers, body: .init(string: """
           {"elevation":\(elevation)}
           """))
    }
}
