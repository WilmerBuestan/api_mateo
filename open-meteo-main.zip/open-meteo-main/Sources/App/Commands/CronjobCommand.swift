/// All cronjobs are now documented in `docs/cronjobs.md`
